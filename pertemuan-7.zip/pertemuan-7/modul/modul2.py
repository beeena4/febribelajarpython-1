import modul1 # import modul1
modul1.cetak_fungsi("Andi") # memanggil fungsi dari modul
