def cetak_fungsi( par ): 
    print ("Selamat datang di FTIK USM : ", par) 
cetak_fungsi("Mahasiswa Baru")