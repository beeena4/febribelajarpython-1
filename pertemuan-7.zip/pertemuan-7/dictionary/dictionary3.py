#Contoh cara menghapus pada Dictionary Python 
dict = {'nama': 'udin', 'usia': 23, 'Class': 'Awal'} 

del dict['nama'] # hapus entri dengan key 'Nama' 
dict.clear () # hapus semua entri di dict 
del dict # hapus dictionary yang sudah ada 

print ("dict['Usia']: ", dict['usia']) 
print ("dict['School']: ", dict['School'])