#Update dictionary python 
dict={'nama': 'udin', 'usia': 23, 'Class': 'Awal'} 
dict['Usia'] = 25; # Mengubah entri yang sudah ada 
dict['School'] = "USM Semarang" # Menambah entri baru 

print ("dict['Usia']: ", dict['usia']) 
print ("dict['School']: ", dict['School'])