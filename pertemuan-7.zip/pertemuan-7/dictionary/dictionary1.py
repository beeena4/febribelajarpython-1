#Contoh cara membuat Dictionary pada Python 
dict = {'nama': 'udin', 'usia': 23, 'Class': 'Awal'} 
print ("dict['nama']: ", dict['nama']) 
print ("dict['Usia']: ", dict['usia'])