#Contoh2 
def input_data (): 
    "fungsi pertama" 
nama=input("Masukan Nama:") 
nim=input ("Masukan NIM:") 
def cetak_string(): 
    print ("ini adalah fungsi cetak string") 
    print ("silahkan masukan data") 
    input_data () 
cetak_string()