#Contoh 1 
def cetak_string(par1, par2): 
    print ("NIM Anda adalah = ",par1)
    print ("Nama Anda adalah = ",par2) 
def hitung (a,b): 
    print ("Hasil penjumlahan ",a, "+", b, "adalah", (a+b)) 
#main program 
nama=input ("Masukan NIm Anda = ") 
nim=input ("Masukan Nama Anda = ") 
cetak_string(nama, nim) 
bill=10 
bil2=12 
hitung (bill,bil2)