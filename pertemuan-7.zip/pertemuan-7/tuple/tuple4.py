tup = ('USM', 'Jaya', 1988, 2019); 
print (tup) 
del tup; 
print ("Setelah menghapus tuple: ") 
print (tup)