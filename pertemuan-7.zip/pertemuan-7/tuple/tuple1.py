tup1 = {'fisika', 'kimia', 1993, 2017}
tup2 = {1, 2, 3, 4, 5}
tup3 = "a", "b", "c", "d"