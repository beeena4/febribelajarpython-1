#Cara mengakses nilai tuple 
tup1 = ('fisika', 'kimia', 1993, 2017) 
tup2 = (1, 2, 3, 4, 5, 6, 7) 
print ("tup1 [0]: ", tup1[0]) 
print ("tup2 [1:5]: ", tup2 [1:5])