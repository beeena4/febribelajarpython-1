tup1 = (20, 38.56)
tup2 = ('USM', 'Jaya') 
# Aksi seperti dibawah ini tidak bisa dilakukan pada tuple python 
# Karena memang nilai pada tuple python tidak bisa diubah 
# tup1 [0] = 100; 
#Jadi, buatlah tuple baru sebagai berikut 
tup3 =  tup1 + tup2 
print (tup3)