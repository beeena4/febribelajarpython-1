# contoh string 5, string5.py
print ("--------------------------------------------")
print ("=========  CONTOH 5,   string5.py  =========")
print ("--------------------------------------------")

kutipantiga = """ini adalah string panjang yang 
terdiri dari beberapa baris dan karakter
yang tidak dapat dicetak seperti
TAB (\ t) dan mereka akan muncul seperti
itu ketika ditampilkan.NEWLINE di dalam
string, baik secara eksplisit diberikan
seperti ini di dalam kurung [\ n],
atau hanya NEWLINE di dalam penugasan
variabel juga akan muncul.""" 
print (kutipantiga) 

print ("--------------------------------------------")
print ("=========  by : FEBRIANA N.A._006  =========")
print ("--------------------------------------------")