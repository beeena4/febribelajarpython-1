# contoh string 1, string1.py
print ("-------------------------------")
print ("===  CONTOH 1,  string1.py  ===")
print ("-------------------------------")

nama = 'FTIK USM'  
pesan = "Belajar bahasa Python di FTIK USM" 
print ("Nama[0]: ", nama[0]) 
print ("Pesan [1:4]: ", pesan[1:4]) 

print ("-------------------------------")
print ("=== by : FEBRIANA N.A._ 006 ===")
print ("-------------------------------")