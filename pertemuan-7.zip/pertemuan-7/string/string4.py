# contoh string 4, string4.py
print ("------------------------------------")
print ("=====  CONTOH 4,   string4.py  =====")
print ("------------------------------------")

print ("My name is %s and weight is %d kg!" % 
('Zara', 21)) 

print ("------------------------------------")
print ("=====  by : FEBRIANA N.A._006  =====")
print ("------------------------------------")