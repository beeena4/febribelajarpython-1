# contoh string 2, string2.py
print ("-------------------------------")
print ("===  CONTOH 2,  string2.py  ===")
print ("-------------------------------")

pesan = 'FTIK USM'  
print ("Perbaharui data tipe string :- ", 
pesan[:6] + 'Python') 

print ("-------------------------------")
print ("=== by : FEBRIANA N.A._ 006 ===")
print ("-------------------------------")