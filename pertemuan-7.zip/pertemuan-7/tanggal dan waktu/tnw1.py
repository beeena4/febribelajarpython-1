import time;  # Digunakan untuk meng-import modul 
time 
ticks = time.time() 
print ("Berjalan sejak 1.00am, 1 Desember 2019:", 
ticks)