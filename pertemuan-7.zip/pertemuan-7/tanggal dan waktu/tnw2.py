#waktu Saat ini 
import time; 
localtime = time.localtime(time.time()) 
print ("Waktu Kita saat ini adalah :", localtime) 

# Waktu yang berformat 
import time; 
localtime = time.asctime( time.localtime(time.time()) ) 
print ("Waktu Kita saat ini adalah :", localtime) 

# Kalender Sebulan 
import calendar 
cal = calendar.month(2019, 12) 
print ("Dibawah ini adalah kalender:") 
print (cal) 