#Contoh cara menghapus nilai pada list python 
list1 = ['TI', 'SI', 'ILKOM', 2010, 2006] 
print (list) 
del list[2] 
print ("Setelah dihapus nilai pada index 2", list)