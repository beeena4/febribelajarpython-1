#Cara mengakses nilai di dalam list Python 
list1 = ['TI', 'SI', 'ILKOM', 2010, 2006]
list2 = ["x", "y", "z", "w"] 

print ("list1 (0): ", list1[0])
print ("list2 [1:5]: ", list2 [1:5])