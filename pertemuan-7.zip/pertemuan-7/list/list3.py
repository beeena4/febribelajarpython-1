# update nilai dalam list
list1 = ['TI', 'SI', 'ILKOM', 2010, 2006]
print ("Nilai ada pada index 2: ", list[2]) 

list[2] = 2001 
print ("Nilai baru ada pada index 2: ", list[2])