#Contoh sederhana pembuatan list 
#pada bahasa pemrograman python 
list1 = ['TI', 'SI', 'ILKOM', 2010, 2006] 
list2 = [1, 2, 3, 4, 5] 
list3 = ["x", "y", "z", "w"]